class CostCalcError(Exception):
    pass
